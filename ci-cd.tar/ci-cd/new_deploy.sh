echo '' > /home/ubuntu/restart.sh
/home/ubuntu/.nvm/versions/node/v18.18.0/bin/node apps/ci-cd/deploy.js
sudo chmod +x /home/ubuntu/restart.sh
/home/ubuntu/restart.sh

