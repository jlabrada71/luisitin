import { _ as _export_sfc, v as vue_cjs_prod } from '../server.mjs';
import { s as serverRenderer } from '../../handlers/renderer.mjs';
import 'unenv/runtime/mock/proxy';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'h3';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';
import 'stream';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_b_nav = vue_cjs_prod.resolveComponent("b-nav");
  const _component_b_nav_item = vue_cjs_prod.resolveComponent("b-nav-item");
  const _component_NuxtPage = vue_cjs_prod.resolveComponent("NuxtPage");
  _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><section id="nav"><h1>Miriela Ulloa</h1>`);
  _push(serverRenderer.exports.ssrRenderComponent(_component_b_nav, { tabs: "" }, {
    default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(serverRenderer.exports.ssrRenderComponent(_component_b_nav_item, {
          to: "/",
          active: ""
        }, {
          default: vue_cjs_prod.withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`Home`);
            } else {
              return [
                vue_cjs_prod.createTextVNode("Home")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(serverRenderer.exports.ssrRenderComponent(_component_b_nav_item, { to: "/gis" }, {
          default: vue_cjs_prod.withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`GIS`);
            } else {
              return [
                vue_cjs_prod.createTextVNode("GIS")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(serverRenderer.exports.ssrRenderComponent(_component_b_nav_item, { to: "/modeling" }, {
          default: vue_cjs_prod.withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`Modeling`);
            } else {
              return [
                vue_cjs_prod.createTextVNode("Modeling")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(serverRenderer.exports.ssrRenderComponent(_component_b_nav_item, { to: "/experience" }, {
          default: vue_cjs_prod.withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`Experience`);
            } else {
              return [
                vue_cjs_prod.createTextVNode("Experience")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(serverRenderer.exports.ssrRenderComponent(_component_b_nav_item, { to: "/contact" }, {
          default: vue_cjs_prod.withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`Contact`);
            } else {
              return [
                vue_cjs_prod.createTextVNode("Contact")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          vue_cjs_prod.createVNode(_component_b_nav_item, {
            to: "/",
            active: ""
          }, {
            default: vue_cjs_prod.withCtx(() => [
              vue_cjs_prod.createTextVNode("Home")
            ]),
            _: 1
          }),
          vue_cjs_prod.createVNode(_component_b_nav_item, { to: "/gis" }, {
            default: vue_cjs_prod.withCtx(() => [
              vue_cjs_prod.createTextVNode("GIS")
            ]),
            _: 1
          }),
          vue_cjs_prod.createVNode(_component_b_nav_item, { to: "/modeling" }, {
            default: vue_cjs_prod.withCtx(() => [
              vue_cjs_prod.createTextVNode("Modeling")
            ]),
            _: 1
          }),
          vue_cjs_prod.createVNode(_component_b_nav_item, { to: "/experience" }, {
            default: vue_cjs_prod.withCtx(() => [
              vue_cjs_prod.createTextVNode("Experience")
            ]),
            _: 1
          }),
          vue_cjs_prod.createVNode(_component_b_nav_item, { to: "/contact" }, {
            default: vue_cjs_prod.withCtx(() => [
              vue_cjs_prod.createTextVNode("Contact")
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</section><section id="content">`);
  _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtPage, null, null, _parent));
  _push(`</section><section id="footer"><h2>Datos de contacto</h2><i class="bi bi-linkedin">https://www.linkedin.com/in/miriela-ulloa-82322935/</i></section>`);
  serverRenderer.exports.ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default.0e9ee550.mjs.map
