import { _ as _export_sfc, v as vue_cjs_prod } from '../server.mjs';
import { s as serverRenderer } from '../../handlers/renderer.mjs';
import 'unenv/runtime/mock/proxy';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'h3';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';
import 'stream';

const micromine = "" + globalThis.__buildAssetsURL("micromine.8beef70c.png");
const _sfc_main = {
  head: {
    title: "Index"
  },
  components: {},
  data() {
    return {
      micromineImg: micromine,
      slide: 0,
      sliding: null
    };
  },
  methods: {
    onSlideStart(slide) {
      this.sliding = true;
    },
    onSlideEnd(slide) {
      this.sliding = false;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><section id="content"><figure><img${serverRenderer.exports.ssrRenderAttr("src", $data.micromineImg)} alt="Modeling ore deposit in micromine"><figcaption>Modelando deposito con Micromine</figcaption></figure></section></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/modeling.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const modeling = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { modeling as default };
//# sourceMappingURL=modeling.ff859c6f.mjs.map
