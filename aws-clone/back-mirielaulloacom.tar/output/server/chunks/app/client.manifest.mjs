const client_manifest = {
  "assets/images/qgis.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "qgis.05ddf7b0.jpg",
    "src": "assets/images/qgis.jpg"
  },
  "assets/images/micromine.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "micromine.8beef70c.png",
    "src": "assets/images/micromine.png"
  },
  "assets/images/home.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "home.fe50f060.jpg",
    "src": "assets/images/home.jpg"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.1ce68403.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "components/ContactInfo.vue",
      "pages/contact.vue",
      "pages/experience.vue",
      "pages/gis.vue",
      "pages/index.vue",
      "pages/modeling.vue",
      "virtual:nuxt:/home/jlabrada/Documents/sources/heroku/mirielaulloacom/.nuxt/error-component.mjs",
      "layouts/custom.vue",
      "layouts/default.vue"
    ]
  },
  "virtual:nuxt:/home/jlabrada/Documents/sources/heroku/mirielaulloacom/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.e7f3a922.mjs",
    "src": "virtual:nuxt:/home/jlabrada/Documents/sources/heroku/mirielaulloacom/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "components/ContactInfo.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ContactInfo.52ab0c34.mjs",
    "src": "components/ContactInfo.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.7287ed4b.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "__plugin-vue_export-helper.7287ed4b.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.7287ed4b.mjs"
  },
  "pages/contact.vue": {
    "resourceType": "script",
    "module": true,
    "file": "contact.af3f2e68.mjs",
    "src": "pages/contact.vue",
    "isDynamicEntry": true,
    "imports": [
      "components/ContactInfo.vue",
      "__plugin-vue_export-helper.7287ed4b.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/experience.vue": {
    "resourceType": "script",
    "module": true,
    "file": "experience.f76223e9.mjs",
    "src": "pages/experience.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.7287ed4b.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": [
      "experience.e2cf1b2b.css"
    ]
  },
  "experience.e2cf1b2b.css": {
    "file": "experience.e2cf1b2b.css",
    "resourceType": "style"
  },
  "pages/gis.vue": {
    "resourceType": "script",
    "module": true,
    "file": "gis.f333d8de.mjs",
    "src": "pages/gis.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.7287ed4b.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "assets": [
      "qgis.05ddf7b0.jpg"
    ]
  },
  "qgis.05ddf7b0.jpg": {
    "file": "qgis.05ddf7b0.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.e3fcb6a0.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.7287ed4b.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "assets": [
      "home.fe50f060.jpg"
    ]
  },
  "home.fe50f060.jpg": {
    "file": "home.fe50f060.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/modeling.vue": {
    "resourceType": "script",
    "module": true,
    "file": "modeling.c33e0d23.mjs",
    "src": "pages/modeling.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.7287ed4b.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "assets": [
      "micromine.8beef70c.png"
    ]
  },
  "micromine.8beef70c.png": {
    "file": "micromine.8beef70c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "layouts/custom.vue": {
    "resourceType": "script",
    "module": true,
    "file": "custom.e7b983be.mjs",
    "src": "layouts/custom.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "components/ContactInfo.vue",
      "__plugin-vue_export-helper.7287ed4b.mjs"
    ],
    "css": [
      "custom.531953d4.css"
    ]
  },
  "custom.531953d4.css": {
    "file": "custom.531953d4.css",
    "resourceType": "style"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.d5aabfb9.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.7287ed4b.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.7d1fac41.mjs",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.7287ed4b.mjs"
    ],
    "css": [
      "error-404.7729cee9.css"
    ]
  },
  "error-404.7729cee9.css": {
    "file": "error-404.7729cee9.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.4a7a84d5.mjs",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.7287ed4b.mjs"
    ],
    "css": [
      "error-500.08851880.css"
    ]
  },
  "error-500.08851880.css": {
    "file": "error-500.08851880.css",
    "resourceType": "style"
  },
  "layouts/custom.css": {
    "resourceType": "style",
    "file": "custom.531953d4.css",
    "src": "layouts/custom.css"
  },
  "pages/experience.css": {
    "resourceType": "style",
    "file": "experience.e2cf1b2b.css",
    "src": "pages/experience.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.08851880.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.7729cee9.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
