ls /home/ubuntu/.pm2/logs
