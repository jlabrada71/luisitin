cat /home/ubuntu/.pm2/logs/tryyourideas.com-error.log
