source /home/ubuntu/.profile
/home/ubuntu/.nvm/versions/node/v18.8.0/bin/node apps/ci-cd/test.js 
