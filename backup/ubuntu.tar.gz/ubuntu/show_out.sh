cat /home/ubuntu/.pm2/logs/tryyourideas.com-out.log
