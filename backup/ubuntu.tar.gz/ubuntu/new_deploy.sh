/home/ubuntu/.nvm/versions/node/v18.8.0/bin/node apps/ci-cd/deploy.js 
