module.exports = {
  apps : [
      {
        name: "tryyourideas.com",
        script: "apps/tryyourideas.com/server/tryyourideas.com.mjs",
        watch: true,
        env: {
            "PORT": 3200,
            "NODE_ENV": "development"
        },
        env_production: {
            "PORT": 3200,
            "NODE_ENV": "production",
        }
      },
  ]
}
