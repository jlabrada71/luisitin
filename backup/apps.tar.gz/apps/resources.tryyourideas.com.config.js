module.exports = {
  apps : [
      {
        name: "resources.tryyourideas.com",
        script: "apps/resources.tryyourideas.com/server.js",
        watch: true,
        env: {
            "PORT": 3400,
            "NODE_ENV": "development"
        },
        env_production: {
            "PORT": 3400,
            "NODE_ENV": "production",
        }
      },
  ]
}
