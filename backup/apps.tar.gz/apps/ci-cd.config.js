module.exports = {
  apps : [
	  {
        	name: "ci-cd",
        	script: "apps/ci-cd/deploy.js",
        	watch: true,
        	env : {
            		"NODE_ENV": "production",
	    		"TIMES": "2",
        	}
	}
  ]
}
